#' @title getRocketData
#' @description Get the current data from Launch Library 2 API, which is needed to run the Rocket Launches Shiny App.
#' @param none no parameters needed
#' @return Returns a concise data frame with all  rocket launches in 2024 and additional information about launches.
#' @examples
#' # data_rockets <- getRocketData()
#' @note If Error occurs: "Error in curl::curl_fetch_memory(url, handle = handle) : etc", run getRocketData() again until the data is returned.
#' @export
getRocketData <- function(){
  
  ##get success data
  res_success <- httr::GET("https://lldev.thespacedevs.com/2.2.0/launch/previous/?limit=100&status=3&window_start__gte=2024-01-01T00%3A01%3A00Z")
  data <- jsonlite::fromJSON(rawToChar(res_success$content))
  data_launch <- data$results
  
  ##get success data after 26/05/24
  res_success_later <- httr::GET("https://lldev.thespacedevs.com/2.2.0/launch/previous/?limit=100&status=3&window_start__gte=2024-05-26T00%3A01%3A00Z")
  data_later <- jsonlite::fromJSON(rawToChar(res_success_later$content))
  data_launch_later <- data_later$results
  
  ##get failure data
  res_failure <- httr::GET("https://lldev.thespacedevs.com/2.2.0/launch/previous/?limit=100&status=4&window_start__gte=2024-01-01T00%3A01%3A00Z")
  
  rawToChar(res_failure$content)
  data_fail <- jsonlite::fromJSON(rawToChar(res_failure$content))
  data_launch_fail <- data_fail$results
  
  ##combining fail and success
  data_pns <- dplyr::bind_rows(data_launch, data_launch_later, data_launch_fail)
  
  ##making data frame with only useful columns and better names
  data_rockets <- as.data.frame(cbind(data_pns$name, data_pns$status$id, data_pns$status$abbrev, data_pns$window_end, data_pns$failreason, data_pns$launch_service_provider$name, data_pns$launch_service_provider$type, data_pns$mission$description, data_pns$mission$type, data_pns$pad$latitude, data_pns$pad$longitude, data_pns$image))
  names <- c("name","success_id","success_abbrev","time_of_launch","failreason","provider_name","provider_category","mission_description", "mission_purpose","latitude","longitude","image_URL")
  colnames(data_rockets) <- names
  data_rockets$latitude <- as.numeric(data_rockets$latitude)
  data_rockets$longitude <- as.numeric(data_rockets$longitude)
  data_rockets$month <- as.numeric(sapply(strsplit(data_rockets$time_of_launch, "-"), "[[", 2))
  
  return(data_rockets)
}


#' @title get_GUI
#' @description Function to Call the Shiny App "Rocket Launches 2024".
#' @param none no parameters needed
#' @return Returns a GUI of a Shiny App that displays rocket launches on a world map. These can be filtered according to success, provider & time frame. Furthermore, there is a statistics tab with some plots.
#' @examples
#' # get_GUI()
#' @note Error message "curl::curl_fetch_memory(url, handle = handle) : Timeout was reached: etc." might occur. Don't stop function in that case. The function will repeat itself automatically until GUI is returned.
#' @export
get_GUI <- function(){
  
  tempdir(check = TRUE)
  library(dplyr)
  library(bslib)
  library(shiny)
  
  ##Loop for error message "Timeout was reached"
  repeat {
    data_rockets<-try(getRocketData())
    if (!(inherits(data_rockets,"try-error"))) 
      break
  }
  
  
  ##shiny app 
  ui <- shiny::fluidPage(
    
    theme = bslib::bs_theme(
      bootswatch = "flatly",
      primary = "#2C3E50"
    ),
    
    shiny::tags$style(shiny::HTML("
    #map {
      height: calc(100vh - 80px) !important;
    }
    .leaflet-container {
      height: 100% !important;
      width: 100% !important;
    }
  ")),
    
    shiny::titlePanel(title = shiny::tags$h1(
      shiny::tags$b("Rocket Launches 2024"),
      shiny::tags$style(HTML("h1 { text-align: center; }")))),
    
    shiny::tabsetPanel(
      
      shiny::tabPanel("Map",
                      shiny::sidebarLayout(
                        
                        sidebarPanel = shiny::sidebarPanel(
                          shiny::helpText("You can filter the shown rocket launches according to the following options:"),
                          shiny::br(),
                          shiny::br(),
                          shiny::sliderInput("month", "Months of 2024", min = 1, max = 12, value = c(1,5)),
                          shiny::checkboxGroupInput("status", 
                                                    label = "Launch Status", 
                                                    choices = list("Success" = 3, 
                                                                   "Failure" = 4),
                                                    selected = c(3, 4)),
                          shiny::checkboxGroupInput("category", 
                                                    label = "Provider Category", 
                                                    choices = unique(data_rockets$provider_category),
                                                    selected = unique(data_rockets$provider_category)
                          ),
                          shiny::helpText("Click on the dots to get more information on the launched objects."),
                          
                          width = 3
                        ),
                        
                        mainPanel = shiny::mainPanel(
                          leaflet::leafletOutput(outputId = "map"),
                          width = 9
                        )
                      )
      ),
      
      shiny::tabPanel("Statistics",
                      shiny::helpText("Here you can find some statistics about the rocket launches in 2024."),
                      shiny::fluidRow( 
                        shiny::column(6, plotOutput("Plot1")), 
                        shiny::column(6, plotOutput("Plot2")),
                        shiny::column(6, plotOutput("Plot3")),
                        shiny::column(6, plotOutput("Plot4"))
                      )
                      
      )
    )
  )
  
  
  server <- function(input, output){
    
    map_df <- shiny::reactive({
      
      data_rockets %>%
        dplyr::filter(month >= input$month[1] & month <= input$month[2]) %>%
        dplyr::filter(success_id %in% input$status) %>%
        dplyr::filter(provider_category %in% input$category)
      
    })
    
    output$map <- leaflet::renderLeaflet({
      
      leaflet::leaflet() %>%
        leaflet::addTiles() %>%
        leaflet::setView(lng = 15, lat = 10, zoom = 1.5) %>%
        leaflet::addCircleMarkers(data = map_df(), 
                                  ~longitude, 
                                  ~latitude, 
                                  radius = 3,
                                  color = ~ifelse(success_id == 3, "green", "red"),
                                  popup = ~paste(
                                    "<strong>Name:</strong>", name, "<br>",
                                    "<strong>Status:</strong>", success_abbrev, "<br>",
                                    "<strong>Time of Launch:</strong>", time_of_launch,"<br>",
                                    "<strong>Provider Type:</strong>", provider_category, "<br>",
                                    "<strong>Provider Name:</strong>", provider_name, "<br>",
                                    "<strong>Purpose:</strong>", mission_purpose,"<br>",
                                    "<strong>Description:</strong>", mission_description,"<br>",
                                    "<img src =", image_URL, "width = '100px'>"
                                  ))
      
    })
    
    # Statistics Tab 
    ##Pie Chart for Provider Ratio
    output$Plot1 <- shiny::renderPlot({
      
      df <- map_df() %>%
        dplyr::count(provider_category) %>%
        dplyr::mutate(percentage = n / sum(n) * 100)
      
      ggplot2::ggplot(data = df, ggplot2::aes(x = "", y = percentage, fill = provider_category)) +
        ggplot2::geom_bar(stat = "identity", width = 1) +
        ggplot2::coord_polar("y") +
        ggplot2::labs(title = "Percentage of Launch Provider Categories",
                      x = NULL,
                      y = NULL,
                      fill = "Categoy of Provider") +
        ggplot2::theme_void() +
        ggplot2::theme(legend.position = "right")
    })
    
    ##Pie Chart for Ratio of Mission Purposes
    output$Plot2 <- shiny::renderPlot({
      
      df <- map_df() %>%
        dplyr::count(mission_purpose) %>%
        dplyr::mutate(percentage = n / sum(n) * 100)
      
      ggplot2::ggplot(data = df, ggplot2::aes(x = "", y = percentage, fill = mission_purpose)) +
        ggplot2::geom_bar(stat = "identity", width = 1) +
        ggplot2::coord_polar("y") +
        ggplot2::labs(title = "Ratio of Mission Purposes",
                      x = NULL,
                      y = NULL,
                      fill = "Mission Purpose") +
        ggplot2::theme_void() +
        ggplot2::theme(legend.position = "right")
    })
    
    ##simple bar chart to display amount of launches per month
    output$Plot3 <- shiny::renderPlot({
      
      ggplot2::ggplot(data = data_rockets, ggplot2::aes(x = month)) +
        ggplot2::geom_bar(fill = "salmon")+
        ggplot2::labs(title = "Amount of Rocket Launches per Month",
                      x = "Month of Rocket Launch")+
        ggplot2::theme_bw()
    })
    
    ##stacked bar chart for Ratio of Providers
    output$Plot4 <- shiny::renderPlot({
      
      ggplot2::ggplot(data = data_rockets, ggplot2::aes(x = "", fill = provider_name)) +
        ggplot2::geom_bar(color = "white")+
        ggplot2::labs(title = "Amount of Rocket Launches per Provider",
                      x = "",
                      fill = "Provider Name") +
        ggplot2::theme_bw()
    })
    
  }
  
  shiny::shinyApp(ui, server)
  
}
